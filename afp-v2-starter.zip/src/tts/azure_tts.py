# Placeholder – wire up Azure Speech in Sprint 2
def synthesize_to_mp3(text: str, voice: str) -> bytes:
    # TODO: implement Azure Speech synthesis
    return b""  # return MP3 bytes
